# -*- coding: utf-8 -*-
"""
Created on Thu Feb  7 15:23:40 2019

@author: bhopp
"""


from easygui import multenterbox, ccbox
import openpyxl
from openpyxl import load_workbook
from fix_border import patch_worksheet
from openpyxl.workbook import Workbook

from openpyxl.cell import Cell
from openpyxl.utils import coordinate_from_string
from openpyxl.comments import Comment

"""

msg = "Customer and Order Info"
title = "WELD PLAN COMPILER"
fieldNames = ["Customer Name: ","SO#: ","JO#: ","Top-Level Drawing#: ","Fan Type","Fan Description: ","Tag#: ","Revision"]
fieldValues = []  # we start with blanks for the values
fieldValues = multenterbox(msg,title, fieldNames)
CN,S,J,TP,FT,D,tn,Rev = fieldValues
# make sure that none of the fields was left blank
while 1:
    if fieldValues == None: break
    errmsg = ""
    for i in range(len(fieldNames)):
      if fieldValues[i].strip() == "":
        errmsg = errmsg + ('"%s" is a required field.\n\n' % fieldNames[i])
    if errmsg == "": break # no problems found
    fieldValues = multenterbox(errmsg, title, fieldNames, fieldValues)

"""
CN= "The Customer"
S = "190207"                  
J = "001A1-0000"
TP = "010-0001"
FT = "Type"
D = "Fan Description"
tn = "X-0000"
Rev = "-"  
#"""


#Below used for importing template without losing borders on merged cells
patch_worksheet()
wb = load_workbook("C:\\Users\\bhopp\\Documents\\Python Scripts\\Weld Code\\WIRTemplateA.xlsx")
WPI = load_workbook("C:\\Users\\bhopp\\Documents\\Python Scripts\\Weld Code\\WeldPlanIndex.xlsx")
def get_border(self, border_style=None, color=None):
    return Border(left=Side(border_style=border_style, color=color),
                             right=Side(border_style=border_style, color=color),
                             top=Side(border_style=border_style, color=color),
                             bottom=Side(border_style=border_style, color=color), )

def update_style(self, ws, cell_range):
    start_cell, end_cell = cell_range.split(':')
    start_coord = coordinate_from_string(start_cell)
    end_coord = coordinate_from_string(end_cell)

    start_row = start_coord[1]
    end_row = end_coord[1]

    start_col = column_index_from_string(start_coord[0])
    end_col = column_index_from_string(end_coord[0])

    border_style = ws.cell(row=start_row, column=start_col).border.left.style
    color = ws.cell(row=start_row, column=start_col).border.left.color

    cellborder = self.get_border(border_style, color)

    for row in range(start_row, end_row + 1):
        for col in range(start_col, end_col + 1):
            ws.cell(row=row, column=col).border = cellborder

def update_borders(self, wb):
    for sheet in wb.sheetnames:
        ws = wb[sheet]
        for each_range in ws.merged_cell_ranges:
            self.update_style(ws, each_range)
#------------------------------------------------------------------------------- 

sheet0=wb.worksheets[0]
WPIsht0=WPI.worksheets[0]
WPIsht1=WPI.worksheets[1]
WPIsht2=WPI.worksheets[2]


weld_list = []
p1_list = []
p2_list = []
part_list = []
part_desc = []
part_weld = []
master_weld = []


import os
if not os.path.exists('C:\\Users\\bhopp\\Documents\\Weld Test Folder\\'+S+'\\'+FT):
    os.makedirs('C:\\Users\\bhopp\\Documents\\Weld Test Folder\\'+S+'\\'+FT) 

WPIsht0['D3'] = TP + " " + D + "-WIR"
WPIsht0['A7'] = CN
WPIsht0['A8'] = "PO#: " +S
WPIsht0['A9'] = FT + " " + D
WPIsht0['A10'] = "TAG#: "+ tn + " JO#: " + J
WPIsht0['C3'] = Rev
WPIsht0['B14'] = D

WPIsht1['E3'] = TP + " " + D + "-WIR"
WPIsht1['A7'] = CN
WPIsht1['A8'] = "PO#: " +S
WPIsht1['A9'] = FT + " " + D
WPIsht1['A10'] = "TAG#: "+ tn + " JO#: " + J
WPIsht1['A11'] = "Drawing#: " + TP
WPIsht1['D3'] = Rev

WPIsht2['D3'] = TP + " " + D + "-WIR"
WPIsht2['A7'] = CN
WPIsht2['A8'] = "PO#: " +S
WPIsht2['A9'] = D
WPIsht2['A10'] = "TAG#: "+ tn + " JO#: " + J
WPIsht2['A11'] = "Drawing#: " + TP
WPIsht2['C3'] = Rev

    

sheet0['A7'] = CN
sheet0['A8'] = "PO#: " +S
sheet0['A9'] = FT + D
sheet0['A10'] = "TAG#: "+ tn + " JO#: " + J
sheet0['A11'] = "Drawing#: " + TP

sheet0['C3'] = Rev


m = 1
for i in range(0,m):
    while 1:
        msg = "Part Info"
        title = "WELD PLAN COMPILER"
        fieldNames = ["Part#: ","Part Description: "]
        fieldValues = []  # we start with blanks for the values
        fieldValues = multenterbox(msg,title, fieldNames)
        P, PD = fieldValues
        PWir = [P + "-WIR"]
        PDlist = [PD]
        part_list.append(PWir)
        part_desc.append(PDlist)
        part_list, part_desc = (list(i) for i in zip(*sorted(zip(part_list,part_desc))))
        sheet0['A3'] = P + "-WIR"
        sheet0['B15'] = P + "-W"
        sheet0['D15'] = PD
        # make sure that none of the fields was left blank
        while 1:
            if fieldValues == None: break
            errmsg = ""
            for i in range(len(fieldNames)):
              if fieldValues[i].strip() == "":
                errmsg = errmsg + ('"%s" is a required field.\n\n' % fieldNames[i])
            if errmsg == "": break # no problems found
            fieldValues = multenterbox(errmsg, title, fieldNames, fieldValues)
        n = 1
        for i in range(0, n): 
            while 1:
                msg = "Weld Description Info"
                title = "WELD PLAN COMPILER"
                fieldNames = ['Weld Description#: ','1st P#: ','2nd P#: ']
                fieldValues = []  # we start with blanks for the values
                fieldValues = multenterbox(msg,title, fieldNames)
                w, p1, p2 = fieldValues
                weld_list.append(w)
                p1_list.append(p1)
                p2_list.append(p2)
                part_weld.append(w)
                master_weld.append(w)
                part_list, master_weld = (list(i) for i in zip(*sorted(zip(part_list,master_weld))))
                
                if ccbox(msg='Add New Weld?', title=' ', choices=('[A]dd Weld', 'Ne[x]t')):
                    pass
                    n = n + 1                     
                else:
                    weld_list, p1_list, p2_list = (list(i) for i in zip(*sorted(zip(weld_list,p1_list,p2_list))))
                    r = 20
                    for weldN in weld_list:
                        sheet0.cell(row=r, column=3).value = weldN
                        r += 1
                    wb.save('C:\\Users\\bhopp\\Documents\\Weld Test Folder\\'+S+'\\'+FT+'\\'+P+'-WIR.xlsx')
                    break
                    
        if ccbox(msg='Add New Part?', title=' ', choices=('[A]dd Part', '[D]one')):
            pass
            m = m + 1            
        else:    
            break
                        
                    
                    
                    
#print(part_list)
#print(part_desc)
#print(master_weld)

r = 13
for index in part_desc:
    WPIsht1.cell(row=r, column=2).value = index
    r += 1

r = 13
for index in part_list:
    WPIsht1.cell(row=r, column=3).value = index
    r += 1
r = 13
for index in master_weld:
    WPIsht1.cell(row=r, column=4).value = index
    r += 1

WPI.save('C:\\Users\\bhopp\\Documents\\Weld Test Folder\\'+S+'\\'+FT+'\\'+FT+'-Weld Plan Index Cover Sheets.xlsx')

                    